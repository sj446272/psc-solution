import os
from dotenv import load_dotenv

base_dir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(base_dir, ".env"))

class Config():
    SECRET_KEY = '^^d8m0o4=n$89puw^()+qzbm4%h-!1n5_0+3%vv%1m4v3+)(*s'
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(base_dir, "psc-library-app.db")

    #Mail Configuration
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = '<gmail username>'
    MAIL_PASSWORD = '<gmail app password>'

    ADMIN = '<admin email id>'