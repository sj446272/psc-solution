from flask import Flask
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_mail import Mail

db = SQLAlchemy()
migrate = Migrate()
mail = Mail()

login_manager = LoginManager()
login_manager.login_view = "security.login"
login_manager.login_message = "Please log in to access this page."


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    app.config['TEMPLATES_AUTO_RELOAD'] = True

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    mail.init_app(app)

    from app.security import bp as security_bp
    app.register_blueprint(security_bp, url_prefix='/')

    from app.library import bp as library_bp
    app.register_blueprint(library_bp, url_prefix='/')

    return app


from app.library.models import Book
from app.library.models import UserBooksMapping
from app.security.models import User