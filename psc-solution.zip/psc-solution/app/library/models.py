from app import db
from datetime import datetime


class Book(db.Model):
    id = db.Column(db.String(36), primary_key=True)
    title = db.Column(db.String(100), index=True, nullable=False)
    author = db.Column(db.String(100), index=True, nullable=False)
    date_of_purchase = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    notes = db.Column(db.String(255), index=True, nullable=False)
    publication = db.Column(db.String(100), index=True, nullable=False)
    isbn = db.Column(db.String(20), index=True, nullable=False, unique=True)
    price = db.Column(db.Float)


class UserBooksMapping(db.Model):
    id = db.Column(db.String(36), primary_key=True)
    user_id = db.Column("user_id", db.Integer, db.ForeignKey("user.id"), primary_key=True)
    book_id = db.Column("book_id", db.Integer, db.ForeignKey("book.id"), primary_key=True)
    added_date = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    deleted_date = db.Column(db.DateTime, nullable=True)


class SharedLogs(db.Model):
    id = db.Column(db.String(36), primary_key=True)
    shared_with_email = db.Column(db.String(100), index=True, unique=True, nullable=False)
    email_body = db.Column(db.String(1024), nullable=False)
    shared_date = db.Column(db.DateTime, index=True, default=datetime.utcnow)