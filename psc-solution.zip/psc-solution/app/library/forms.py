from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField, FloatField
from wtforms.validators import DataRequired, Email, Optional, Length, EqualTo


class AddNewBookForm(FlaskForm):
    title = StringField("Book Title", validators=[DataRequired(), Length(min=3, max=50), Optional(strip_whitespace=True)])
    author = StringField("Book Author", validators=[DataRequired(), Length(min=3, max=50), Optional(strip_whitespace=True)])
    publication = StringField("Publication", validators=[DataRequired(), Length(min=3, max=50), Optional(strip_whitespace=True)])
    isbn = StringField("ISBN", validators=[DataRequired(), Length(min=13, max=20)])
    notes = TextAreaField("Notes", validators=[DataRequired(), Length(min=10, max=255)])
    price = FloatField("Price", validators=[DataRequired(), Optional(strip_whitespace=True)])
    submit = SubmitField("Submit")

class ShareForm(FlaskForm):
    shared_with_email = StringField("Email", validators=[DataRequired(), Email(), Optional(strip_whitespace=True)])
    share = SubmitField("Share My Books")