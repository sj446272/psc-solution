from app.library import bp
from flask import render_template, flash, redirect, request, url_for
from flask_login import current_user, login_required
from .models import Book, UserBooksMapping, SharedLogs
from app.security.models import User
from .forms import AddNewBookForm, ShareForm
from app import db
import uuid
from datetime import datetime
from config import Config
from flask_mail import Message
from app import mail


@bp.route('/my-books', methods=['GET'])
@login_required
def myBooks():
    data = db.session.query(Book).filter(Book.id.in_(tuple(row.book_id for row in UserBooksMapping.query.filter_by(user_id=current_user.get_id(), deleted_date=None)))).all()

    form = ShareForm()
    
    return render_template('my-books.html', title="My Books", data=data, form=form)


@bp.route('/add-to-my-books/<string:book_id>', methods=['GET'])
@login_required
def addToMyBooks(book_id):
    try:
        current_user_id = current_user.get_id()
        mapObj = UserBooksMapping.query.filter_by(user_id=current_user_id, book_id=book_id, deleted_date=None).first()    
        bookObj = Book.query.get(book_id)
        if not bookObj:
            flash("Requested Book is not exists", category='danger')
        elif mapObj:
            flash(f"{bookObj.title} Book is already in collection.", category='danger')
        else:
            mapObj = UserBooksMapping(id = str(uuid.uuid1()), user_id=current_user_id, book_id=book_id)

            db.session.add(mapObj)
            db.session.commit()

            flash(f"{bookObj.title} Book had added in collection.", category='success')
    except Exception as ex:
        flash("Something went wrong!" + str(ex), category='danger')
    
    return redirect(url_for("library.myBooks"))


@bp.route('/remove-from-my-books/<string:book_id>', methods=['GET'])
@login_required
def removeFromMyBooks(book_id):
    try:
        mapObj = UserBooksMapping.query.filter_by(user_id=current_user.get_id(), book_id=book_id, deleted_date=None).first()
        mapObj.deleted_date = datetime.now()
        db.session.commit()

        bookObj = Book.query.get(book_id)

        flash(f"{bookObj.title} Book removed successfully from your Books!", category='success')
        
    except Exception as ex:
        flash("Something went wrong!", category='danger')
    
    return redirect(url_for("library.myBooks"))
    


@bp.route('/all-books', methods=['GET'])
@login_required
def allBooks():

    data = Book.query.all()
    
    return render_template('all-books.html', title="All Books", data=data)


@bp.route('/add-new-book', methods=['GET', 'POST'])
@login_required
def addNewBook():
    form = AddNewBookForm()

    if request.method == 'POST' and form.validate_on_submit():
        bookObj = Book.query.filter_by(isbn=form.isbn.data).first()
        if bookObj:
            flash("Book with this ISBN is already exists, You can try edit option.", category='danger')
            return render_template('add-book.html', title="Add New Book", form = form)
        
        bookObj = Book(id = str(uuid.uuid1()), title=form.title.data, author=form.author.data, 
                        publication=form.publication.data, isbn=form.isbn.data, price=form.price.data, notes=form.notes.data)
        
        db.session.add(bookObj)
        db.session.commit()

        return redirect(url_for("library.allBooks"))

    return render_template('add-book.html', title="Add New Book", form=form)

@bp.route('/edit-book/<string:book_id>', methods=['GET', 'POST'])
@login_required
def editBook(book_id):
    try:

        bookObj = Book.query.get(book_id)

        form = AddNewBookForm()

        if request.method == 'POST' and form.validate_on_submit():
            bookObj.title = form.title.data
            bookObj.author = form.author.data
            bookObj.publication = form.publication.data
            bookObj.isbn = form.isbn.data
            bookObj.price = form.price.data
            bookObj.notes = form.notes.data
            db.session.commit()

            flash(f"'{bookObj.title} - (ISBN: {bookObj.isbn}') Book updated successfully.", category="success")
            return redirect(url_for("library.allBooks"))
        
        form.title.data = bookObj.title
        form.author.data = bookObj.author
        form.publication.data = bookObj.publication
        form.isbn.data = bookObj.isbn
        form.price.data = bookObj.price
        form.notes.data = bookObj.notes

        return render_template('add-book.html', title="Edit Book", form=form)
    except Exception as ex:
        flash("Book is not exists" + str(ex), category='danger')
        return render_template('add-book.html', title="Edit Book")

@bp.route('/share-book', methods=['POST'])
@login_required
def shareBook():

    form = ShareForm()

    if request.method == 'POST' and form.validate_on_submit():
        userObj = User.query.get(current_user.get_id())

        msg = Message(f"PSC Library Books shared by {userObj.first_name} {userObj.last_name}",
                    sender=Config.ADMIN,
                    recipients=[form.shared_with_email.data])
        msg.html = f'''
                    <h2>List Of Books</h2>
                    '''
        
        data = db.session.query(Book).filter(Book.id.in_(tuple(row.book_id for row in UserBooksMapping.query.filter_by(user_id=userObj.id, deleted_date=None)))).all()
        msg.html += '<ul>'
        for row in data:
            msg.html += f'''
                            <li>Title: {row.title}
                                <ul>
                                    <li>Author: {row.author}</li>
                                    <li>Publication: {row.publication}</li>
                                    <li>Isbn: {row.isbn}</li>
                                    <li>Price: {row.price}</li>
                                    <li>Notes: {row.notes}</li>
                                <ul>
                            </li>
                        '''
        
        msg.html += '</ul><br /><br /><br />'

        msg.html += f'''<a href="{url_for("security.login", _external=True)}"> Powered By PSC Library App</a> '''

        mail.send(msg)

        sharedObj = SharedLogs(id = str(uuid.uuid1()), shared_with_email=form.shared_with_email.data, email_body = msg.html)
        db.session.add(sharedObj)
        db.session.commit()

        flash(f"Books Shared with {form.shared_with_email.data} successfully", category='success')
        return redirect(url_for("library.myBooks"))
    
    flash("Incorrect Email ID Provided to Sharing The Book", category='danger')
    return redirect(url_for("library.myBooks"))