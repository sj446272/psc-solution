from flask import Blueprint

bp = Blueprint("security", __name__,
                template_folder='templates',
                static_folder='static')

from app.security import routes