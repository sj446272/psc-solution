from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email, Optional, Length, EqualTo
from .models import User


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(), Optional(strip_whitespace=True)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=16)])
    login = SubmitField("Log In")


class RegistrationForm(FlaskForm):
    first_name = StringField("First Name", validators=[DataRequired(), Length(min=3, max=25), Optional(strip_whitespace=True)])
    last_name = StringField("Last Name", validators=[DataRequired(), Length(min=3, max=25), Optional(strip_whitespace=True)])
    email = StringField("Email", validators=[DataRequired(), Email(), Optional(strip_whitespace=True)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=16)])
    password2 = PasswordField("Repeat Password", validators=[DataRequired(), EqualTo("password")])
    submit = SubmitField("Register")

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError("User has already register with this email.")
