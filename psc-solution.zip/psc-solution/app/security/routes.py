from app.security import bp
from flask import render_template, flash, redirect, request, url_for
from flask_login import current_user, login_user, logout_user
from .models import User
from .forms import LoginForm, RegistrationForm
from app import db
import uuid
from datetime import datetime
from flask_mail import Message
from app import mail
from config import Config

@bp.route('/', methods=['GET', 'POST'])  
def login():
    if current_user.is_authenticated:
        return redirect(url_for("security.logout"))
    
    form = LoginForm()
    
    if request.method == 'POST' and  form.validate_on_submit():
        userObj = User.query.filter_by(email=form.email.data).first()
        if not userObj:
            flash("User is not exists with this email ID.", category='info')
            return render_template('login.html', title="Login", form = form)        

        if userObj.status != 'active':        
            flash("User is not an active status, Please Contact Admin.", category='danger')
            return render_template('login.html', title="Login", form = form)

        if not userObj.check_password(form.password.data):
            flash("Invalid username or password.", category="danger")
            return render_template('login.html', title="Login", form = form)
        
        login_user(userObj)
        return redirect(url_for("library.myBooks"))
    
    return render_template('login.html', title="Login", form = form)


@bp.route('/create-an-account', methods=['GET', 'POST'])
def createAnAccount():
    if current_user.is_authenticated:
        return redirect(url_for("security.logout"))

    form = RegistrationForm()
    
    if request.method == 'POST' and form.validate_on_submit():
        userObj = User.query.filter_by(email=form.email.data).first()
        if userObj:
            flash("User is already exists with this email ID.", category='danger')
            return render_template('create-an-account.html', title="Create an Account", form = form)
        activation_key = str(uuid.uuid1())
        userObj = User(id = str(uuid.uuid1()), first_name=form.first_name.data, last_name=form.last_name.data, 
                    email=form.email.data, status='inactive', activation_key = activation_key)
        userObj.set_password(form.password.data)

        db.session.add(userObj)
        db.session.commit()

        msg = Message("Activation Link For PSC Library App",
                    sender=Config.ADMIN,
                    recipients=[form.email.data])
        msg.html = f'''
                    Please click on below link to activate your PSC Library App Account. <br /><br />

                    <a target="_blank" href="{url_for("security.activateAccount", activation_key=activation_key, _external=True)}">Activate My Acccount</a>
        
                    '''
        mail.send(msg)

        flash("Please check your email to activate your PSC Library App Account.", category='success')
        return redirect(url_for("security.login"))

    return render_template('create-an-account.html', title="Create an Account", form=form)

@bp.route('/activate-account/<string:activation_key>')  
def activateAccount(activation_key):
    userObj = User.query.filter_by(activation_key=activation_key, status='inactive').first()
    if userObj:
        userObj.status = 'active'
        userObj.activation_date = datetime.now()
        db.session.commit()
        login_user(userObj)
        flash("Your account has been activated successfully!", category='success')
        return redirect(url_for("library.allBooks"))
    else:
        flash("Activation key is incorrect or account is already activated!", category='danger')
        return redirect(url_for("security.login"))
    
    

@bp.route('/logout')  
def logout():
    logout_user()
    return redirect(url_for("security.login"))

